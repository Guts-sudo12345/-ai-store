# AI Store Telegram bot — starter version

## What works
- `/start` welcome screen and inline menu
- Gemini and ChatGPT catalogue sections
- Product information screens
- Purchase request sent to admin if `ADMIN_CHAT_ID` is configured
- Support and order placeholder screens
- Optional Mini App button when `WEBAPP_URL` is a public HTTPS URL

This is a starter bot, not a complete production store. It does not collect payments, confirm payments, or store a durable order history yet.

## Setup
1. Install Python 3.11 or newer.
2. Create a bot with Telegram's official `@BotFather` and copy its token.
3. Copy `.env.example` to `.env`, then add your token and optional settings.
4. Install dependencies:
   `python -m pip install -r requirements.txt`
5. Start the bot:
   `python bot.py`
6. Open your bot in Telegram and send `/start`.

Keep `.env` private. Never share the bot token in chats or publish it in source code.

## Mini App
Set `WEBAPP_URL` to the public HTTPS URL where your HTML app is hosted. A local file path such as `file:///...` will not work inside Telegram. The existing HTML prototype must be hosted on HTTPS before the Mini App button appears.

## Admin purchase requests
To find your numeric Telegram user ID, use a trusted Telegram ID bot or add a temporary ID command before deployment. Set that numeric ID in `ADMIN_CHAT_ID`. When a user taps “Запросить условия покупки”, the bot forwards a request to that chat if the ID is configured.

## Before public launch
- Set real, verified product descriptions and prices.
- Add database-backed orders and secure admin-only confirmation actions.
- Define refund and support terms.
- Confirm the sale and activation method is allowed by the relevant provider.
- Do not request or store customers' passwords or one-time login codes.
- Run the bot continuously on a server or hosting service.
