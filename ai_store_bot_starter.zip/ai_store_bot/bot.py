import os
import logging
from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart, Command
from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton,
    WebAppInfo
)
from aiogram.utils.keyboard import InlineKeyboardBuilder
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN", "").strip()
WEBAPP_URL = os.getenv("WEBAPP_URL", "").strip()
SUPPORT_USERNAME = os.getenv("SUPPORT_USERNAME", "").strip().lstrip("@")

logging.basicConfig(level=logging.INFO)
dp = Dispatcher()

PRODUCTS = {
    "gemini": [
        ("Google AI plan", "Официальный тариф Google AI. Актуальную доступность и цену нужно подтвердить перед заказом.")
    ],
    "chatgpt": [
        ("ChatGPT Plus", "Информация о тарифе ChatGPT Plus. Доступный официальный способ оформления нужно подтвердить перед заказом."),
        ("Другие варианты ChatGPT", "Дополнительные варианты добавляются после проверки актуальных условий.")
    ],
}

def main_keyboard():
    rows = [
        [InlineKeyboardButton(text="✨ Каталог Gemini", callback_data="catalog:gemini")],
        [InlineKeyboardButton(text="🤖 Каталог ChatGPT", callback_data="catalog:chatgpt")],
    ]
    if WEBAPP_URL.startswith("https://"):
        rows.append([InlineKeyboardButton(text="🛍 Открыть магазин", web_app=WebAppInfo(url=WEBAPP_URL))])
    rows.extend([
        [InlineKeyboardButton(text="📦 Мои заказы", callback_data="orders")],
        [InlineKeyboardButton(text="🎧 Поддержка", callback_data="support")],
    ])
    return InlineKeyboardMarkup(inline_keyboard=rows)

@dp.message(CommandStart())
async def start(message: Message):
    text = (
        "✦ <b>Добро пожаловать в AI Store!</b>\n\n"
        "Здесь можно посмотреть товары, связанные с Gemini и ChatGPT.\n"
        "Перед подтверждением заказа администратор сообщит точную цену, наличие "
        "и способ официальной активации.\n\n"
        "🔒 Никогда не отправляй нам пароль от Google или OpenAI."
    )
    await message.answer(text, reply_markup=main_keyboard(), parse_mode="HTML")

@dp.message(Command("help"))
async def help_command(message: Message):
    await message.answer("Используй кнопки меню ниже. Для начала нажми /start.")

@dp.callback_query(F.data.startswith("catalog:"))
async def catalog(callback: CallbackQuery):
    category = callback.data.split(":", 1)[1]
    title = "✨ Gemini" if category == "gemini" else "🤖 ChatGPT"
    builder = InlineKeyboardBuilder()
    for i, (name, description) in enumerate(PRODUCTS[category]):
        builder.row(InlineKeyboardButton(
            text=f"ℹ️ {name}",
            callback_data=f"product:{category}:{i}"
        ))
    builder.row(InlineKeyboardButton(text="⬅️ Главное меню", callback_data="home"))
    await callback.message.edit_text(
        f"<b>{title}</b>\n\nВыбери позицию для просмотра подробностей.",
        reply_markup=builder.as_markup(),
        parse_mode="HTML"
    )
    await callback.answer()

@dp.callback_query(F.data.startswith("product:"))
async def product_detail(callback: CallbackQuery):
    _, category, index_text = callback.data.split(":")
    try:
        name, description = PRODUCTS[category][int(index_text)]
    except (KeyError, IndexError, ValueError):
        await callback.answer("Товар не найден.", show_alert=True)
        return
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✉️ Запросить условия покупки", callback_data=f"request:{category}:{index_text}")],
        [InlineKeyboardButton(text="⬅️ Назад к товарам", callback_data=f"catalog:{category}")],
        [InlineKeyboardButton(text="🏠 Главное меню", callback_data="home")]
    ])
    await callback.message.edit_text(
        f"<b>{name}</b>\n\n{description}\n\n"
        "💳 Цена: уточняется перед заказом.\n"
        "📌 Оплата и выдача в этой версии подтверждаются вручную.\n"
        "Не передавай пароль или коды входа от личного аккаунта.",
        reply_markup=keyboard,
        parse_mode="HTML"
    )
    await callback.answer()

@dp.callback_query(F.data.startswith("request:"))
async def request_purchase(callback: CallbackQuery):
    _, category, index_text = callback.data.split(":")
    name, _ = PRODUCTS[category][int(index_text)]
    # This is a request only, not a payment or confirmed order.
    user = callback.from_user
    admin_id = os.getenv("ADMIN_CHAT_ID", "").strip()
    if admin_id:
        try:
            await callback.bot.send_message(
                int(admin_id),
                f"🛒 <b>Запрос на покупку</b>\nТовар: {name}\n"
                f"Пользователь: {user.full_name}\nTelegram ID: <code>{user.id}</code>\n"
                f"Username: @{user.username or 'не указан'}",
                parse_mode="HTML"
            )
        except Exception:
            logging.exception("Could not notify admin")
    support_text = "Запрос сформирован. Администратор должен подтвердить наличие и цену."
    if SUPPORT_USERNAME:
        support_text += f"\n\nПоддержка: @{SUPPORT_USERNAME}"
    await callback.message.edit_text(
        f"✅ <b>Запрос на покупку</b>\n\nТовар: {name}\n\n{support_text}\n\n"
        "Это не подтверждение оплаты и не завершённый заказ.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🏠 Главное меню", callback_data="home")]
        ]),
        parse_mode="HTML"
    )
    await callback.answer("Запрос создан")

@dp.callback_query(F.data == "orders")
async def orders(callback: CallbackQuery):
    await callback.message.edit_text(
        "📦 <b>Мои заказы</b>\n\nВ стартовой версии подтверждённые заказы ещё не сохраняются. "
        "На следующем этапе подключим базу данных и статусы заказов.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🏠 Главное меню", callback_data="home")]
        ]),
        parse_mode="HTML"
    )
    await callback.answer()

@dp.callback_query(F.data == "support")
async def support(callback: CallbackQuery):
    text = "🎧 <b>Поддержка</b>\n\n"
    text += f"Напиши @{SUPPORT_USERNAME}, если настроен контакт поддержки." if SUPPORT_USERNAME else \
            "Контакт поддержки пока не настроен. Укажи SUPPORT_USERNAME в файле .env."
    await callback.message.edit_text(
        text,
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🏠 Главное меню", callback_data="home")]
        ]),
        parse_mode="HTML"
    )
    await callback.answer()

@dp.callback_query(F.data == "home")
async def home(callback: CallbackQuery):
    await callback.message.edit_text(
        "✦ <b>AI Store</b>\n\nВыбери раздел:",
        reply_markup=main_keyboard(),
        parse_mode="HTML"
    )
    await callback.answer()

async def main():
    if not TOKEN:
        raise RuntimeError("BOT_TOKEN is missing. Copy .env.example to .env and add your bot token.")
    bot = Bot(TOKEN)
    await dp.start_polling(bot)

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
